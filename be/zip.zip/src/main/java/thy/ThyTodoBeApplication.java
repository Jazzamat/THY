package thy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThyTodoBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThyTodoBeApplication.class, args);
	}

}
