package thy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThyTodoBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
